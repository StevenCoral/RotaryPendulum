%% Balance Control
% LQR Weighting Matrices
Q = diag([1 1 1 1]);
R = 1;
K = lqr(A,B,Q,R)
