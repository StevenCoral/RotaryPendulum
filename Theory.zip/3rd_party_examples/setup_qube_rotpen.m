%% Load Model
qube_rotpen_param;
% Set open-loop state-space model of rotary single-inverted pendulum (SIP)
QUBE_ROTPEN_ABCD_eqns;
% Display matrices
A
B
